# Bridge X

An OpenAI-compatible local gateway for ZCode, with native tool calls, SSE streaming, and a persistent tool receipt journal. This is **12.12.3-beta.1**.

## Features

- Streaming and non-streaming `/v1/chat/completions` responses.
- Native Molab frontend tool events validated against the client's JSON Schema.
- Sequential tool delivery, matching tool results, and independent execution scopes for foreground and memory tasks.
- SQLite recovery with protection against repeating unconfirmed mutations.
- Bounded recovery from explicit rate rejections before any answer or tool input.
- Offline HTTP and real local file/terminal acceptance checks without provider credentials.

## Architecture

```mermaid
flowchart LR
    P[AI provider] -->|text and native proposals| B[Bridge X]
    B -->|OpenAI-compatible messages| C[ZCode or compatible client]
    C -->|execute approved actions| T[Tools]
    T -->|execution results| C
    C -->|tool receipts| B
    B -->|native tool results| P
```

The gateway validates and delivers calls. The client executes tools. A proposed call is not evidence of execution.

## Requirements

- Python 3.11 or newer. This release is checked on Windows with Python 3.13; other Python versions and operating systems are not certified by this release run.
- The pinned packages in `requirements.txt`; `requirements-dev.txt` adds the test tools.
- A compatible client for interactive agent work. Molab requires a current operator-supplied runtime configuration. A notebook URL alone is insufficient.

## Quick Start

Windows shortcut: after preparing your local Molab configuration below, double-click `start.bat`. It creates `.venv` and installs the pinned runtime dependencies if needed, then starts the same Python CLI. Python 3.11+ must be available through `py -3` or `python`; first-time installation needs package-download access. Existing configuration and other servers are not changed. CLI arguments are forwarded, for example `start.bat --provider fake --port 18787`.

Download the prepared release ZIP and extract it. In PowerShell, open its project directory. The commands below use a test port, **18787**, so an existing gateway on 8787 can remain running.

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m tools.configure
.\.venv\Scripts\python.exe -m bridge_x --provider fake --port 18787
```

The configuration command creates placeholders and never overwrites an existing local file. The **fake** provider is an offline protocol simulator; it requires no account and is not an AI model. Leave the server terminal open. In another PowerShell terminal:

```powershell
Invoke-RestMethod http://127.0.0.1:18787/health
```

Expect `status: ok`, version `12.12.3-beta.1`, and provider `fake`. Stop your test server with Ctrl+C before proceeding. The Python CLI never installs software; `start.bat` downloads pinned packages only when its environment needs setup.

### Connect your own Molab runtime

Edit the generated `.molab_local.json` locally, using values for a runtime you are authorized to use. Check syntax without contacting Molab:

```powershell
.\.venv\Scripts\python.exe -m bridge_x --check-config
```

Generate a separate local gateway key and retain it in this terminal for startup:

```powershell
$env:BRIDGEX_LOCAL_KEY = & .\.venv\Scripts\python.exe -c "import secrets; print(secrets.token_urlsafe(32))"
.\.venv\Scripts\python.exe -m bridge_x
```

Enter the same key in your client locally. This does not create or replace a provider credential. Native Molab startup reads the configured runtime and, if needed, changes only its AI mode to `manual`. It never retrieves credentials from a browser. Successful syntax checking does not establish upstream availability.

## Configuration

The complete supported file structure is in [`examples/.molab_local.example.json`](examples/.molab_local.example.json).

| File field | Meaning |
|---|---|
| `chat_url` | Required current HTTPS Molab runtime endpoint ending in `/api/ai/chat`; the supported host suffix is `.sb.molab.run`. |
| `marimo_session_id` | Required session identifier supplied by the operator. |
| `marimo_server_token` | Runtime token if required; an empty string is supported. |
| `http_headers` | Optional explicit headers for this runtime; unsafe/reserved headers are rejected. |
| `notebook_url` | Optional reference, not a replacement for the runtime endpoint. |

Configuration is read from the project root or `BRIDGEX_MOLAB_CONFIG`. The file and any local environment settings must stay private. `.env` files are **not** loaded automatically. All supported environment variables, defaults, limits, and API endpoints are documented in [`docs/CONFIGURATION.md`](docs/CONFIGURATION.md).

## Connecting a Compatible Client

For the normal Molab launch, use these ZCode custom-provider settings:

| Setting | Value |
|---|---|
| API format | OpenAI Chat Completions |
| Base URL | `http://127.0.0.1:8787/v1` |
| Model | `molab-glm` |
| API key | Your `BRIDGEX_LOCAL_KEY` value |

If you choose another `--port`, update the base URL accordingly. For offline testing on 18787, use `bridge-x-fake` and the default demo local key `molab-local`. Replace that demo key for normal operation. The listener is always `127.0.0.1`; this release has no public hosting mode.

## Tool Calling

Send standard `tools` schemas and return real `role: tool` messages with matching call IDs. The Molab adapter supplies frontend tools and accepts complete native input events. It buffers executable calls until successful stream termination and validates them before delivery. With parallel calls disabled, it delivers one action and lets the model re-plan after its receipt. Legacy text parsers remain compatibility code and are not the default native path.

## Streaming

Requests with `stream: true` receive SSE role/content/tool deltas and heartbeat comments during waits. UTF-8 and event boundaries are checked. A terminal error emits an error event without a fabricated successful `[DONE]`. Clients must process errors inside an HTTP 200 SSE response.

## State Recovery

The local SQLite journal stores operation metadata, receipts, execution scopes, and cooldown state. Reuse the same client session identity and journal file when resuming. Unconfirmed mutations remain unconfirmed; the gateway does not execute or blindly replay shell commands. Back up SQLite using its backup API while active, or copy it only after your gateway stops. Do not delete pending records merely to continue a task.

## Testing

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe -m pip check
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe LOCAL_HTTP_ACCEPTANCE.py
.\.venv\Scripts\python.exe -m tools.native_css_acceptance
```

The HTTP check starts its own temporary Uvicorn server on a free loopback port and closes it. The CSS check uses a **scripted native upstream fixture**, executes real Read → Edit → Read → Python/Bash-equivalent actions, checks exact bytes and a neighboring file, and returns receipts through the gateway. It is not an installed-ZCode or live-Molab test. Both need test dependencies. `LIVE_CHECK.py` is retained for test compatibility; invoking it explicitly contacts the configured local live gateway and is not part of offline acceptance.

## Troubleshooting

| Problem | Diagnosis and action |
|---|---|
| `PORT_UNAVAILABLE` | Choose a free `--port`; stop only your own server. No process is stopped automatically. |
| `MOLAB_CONFIG_MISSING` / `PLACEHOLDER` / `INVALID` | Create the template, replace placeholders locally, and run `--check-config`. |
| `MOLAB_RUNTIME_GONE` | The configured runtime returned 410. Start your notebook runtime and update its connection values. Changing native mode does not restore an expired runtime. |
| `MOLAB_ACCESS_DENIED` | Verify your own current runtime credentials. |
| `MOLAB_NATIVE_MODE_REQUIRED` / `UNKNOWN` | The runtime is in notebook code mode, or its page does not expose a readable mode. Check runtime access; native client tools require `manual` or `agent`. |
| Upstream unavailable / timeout | Check runtime availability. An unknown outcome is not automatically repeated. |
| HTTP 429 / SSE rate error | Respect the reported delay. Up to two extra attempts are permitted only for explicit pre-output rejections in verified native mode, within the total deadline. Permanent quota failures are distinct. |
| SSE error / incomplete stream | Inspect the sanitized error code. Do not treat partial tool arguments or HTTP 200 as success. |
| Tool schema / receipt error | Use exact declared argument types and matching call IDs; supply the real execution result. |
| SQLite error / unconfirmed mutation | Use a writable journal location and inspect operation status. Preserve the journal; verify uncertain effects before resuming. |

## Limitations

The Molab adapter is specific to its configured marimo runtime interface. Runtime expiration, upstream changes, quotas, and long outages remain external constraints. Rate recovery has a total deadline and does not guarantee uninterrupted long tasks. Other OpenAI-compatible providers require an explicit operator-supplied HTTPS endpoint; their behavior is not certified by this offline release check. The gateway is not a tool executor or a public multi-user service.

## Project Status

Beta. See [`RELEASE_NOTES.md`](RELEASE_NOTES.md) and [`docs/VALIDATION.md`](docs/VALIDATION.md) for the checks actually performed on this public copy and their limits. Security handling is described in [`SECURITY.md`](SECURITY.md).

## Changelog

See [`CHANGELOG.md`](CHANGELOG.md) for the history supported by the project's existing reports.
