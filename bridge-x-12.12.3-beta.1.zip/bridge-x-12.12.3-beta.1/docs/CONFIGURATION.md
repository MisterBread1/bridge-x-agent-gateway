# Configuration and API reference

Environment variables are read by `Settings.from_env()`. `.env` is not loaded. Python `Settings()` retains compatibility defaults for library tests; use `Settings.from_env()` for the CLI behavior below.

| Variable | Default | Purpose |
|---|---|---|
| `BRIDGEX_PROVIDER` | `molab` | `molab`, `fake`, or `openai-compatible`. CLI `--provider` overrides it. |
| `BRIDGEX_LOCAL_KEY` | `molab-local` | Local Bearer key; use a unique nonempty value for normal operation. |
| `BRIDGEX_MOLAB_CONFIG` | Project `.molab_local.json` | Explicit local Molab connection file. |
| `BRIDGEX_JOURNAL_PATH` | `bridge_x_state.sqlite3` | Journal path relative to the working directory, or `:memory:` for disposable tests. |
| `BRIDGEX_TIMEOUT_SECONDS` | `600` | Total gateway request deadline, including queue and retries. |
| `BRIDGEX_ACTION_CHARS` | `2200` | Advisory action size, 1000–12000; not a provider token limit. |
| `BRIDGEX_MOLAB_TOOL_MODE` | `native` | `native`, `auto`, or explicit legacy `structured`. Native is the public default. |
| `BRIDGEX_MOLAB_REQUEST_INTERVAL` | `15` | Minimum seconds between generation starts. |
| `BRIDGEX_MOLAB_BACKGROUND_INTERVAL` | `30` | Minimum seconds between background starts. |
| `BRIDGEX_MOLAB_BACKGROUND_IDLE` | `10` | Foreground idle period before background admission. |
| `BRIDGEX_MOLAB_COOLDOWN` | `60` | Initial fallback pause after rate rejection; explicit longer upstream delays win. |
| `BRIDGEX_MOLAB_MAX_QUEUE_WAIT` | `120` | Queue budget when transparent rate recovery is disabled. With verified native recovery, the remaining total deadline bounds admission. |
| `BRIDGEX_MOLAB_RATE_RETRIES` | `2` | 0–2 extra attempts after an explicit rejection before output, in verified native mode only. |
| `BRIDGEX_MOLAB_RATE_RECOVERY` | `900` | Seconds to retain increased caution after a rate limit. |
| `BRIDGEX_GENERIC_URL` | Empty | Operator-supplied documented HTTPS endpoint for the generic adapter. |
| `BRIDGEX_GENERIC_MODEL` | Empty | Model identifier for the generic adapter. |
| `BRIDGEX_GENERIC_API_KEY` | Empty | Explicit generic upstream key. |

Numeric time settings must be finite and positive. `BRIDGEX_LOCAL_KEY` authenticates the local gateway; it is not a Molab token. Do not put unsupported fields in the example and expect them to affect the application.

CLI options: `--provider`, `--port` (default 8787, loopback only, zero chooses a free port), and `--check-config` (syntax only; no remote access or SQLite creation).

## Local HTTP endpoints

| Endpoint | Local Bearer key | Behavior |
|---|---|---|
| `GET /health` | No | Process version and selected provider; not proof of upstream access. |
| `GET /ready` | No | Reports whether this process has observed a live response. |
| `GET /v1/models` | Yes | Configured model identifier. |
| `GET /v1/capabilities` | Yes | Declared protocol and observed native capability. |
| `POST /v1/chat/completions` | Yes | OpenAI-compatible chat, native calls, and SSE. |
| `GET /diagnostics` | Yes | Bounded sanitized metadata and pacing status. |
| `GET /v1/operations/{call_id}` | Yes | Operation state, not a request to execute it. |
| `POST /v1/operations/{call_id}/verification` | Yes | Explicit hash verification against recorded expected/observed results. |

The server never runs tools itself. Tool schemas, results, and transcript text are untrusted input, not higher-priority instructions.

## Persistence

The journal includes operation transitions and separate execution scopes. Historical receipt reconciliation uses the original conversation owner. Unconfirmed mutations in the same scope block unsafe continuation. `provider_control` records cooldown and the recent rate-pressure timestamp; a runtime/session change does not intentionally reset that state.

Keep one active bridge for a given journal/quota. Admission priority is process-local, not a distributed limiter. A successful completion does not prove that a final client action was executed unless its receipt is available.
