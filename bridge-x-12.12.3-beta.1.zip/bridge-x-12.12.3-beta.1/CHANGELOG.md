# Changelog

This is a reconstructed history from the existing project reports, not a claim of newly rerun historical test results. The source has no verified complete commit history.

## 12.12.3-beta.1 — Public release preparation

- Preserves native frontend tools, streaming, receipt reconciliation, execution scopes, and the SQLite operation ledger.
- Keeps bounded retries for explicit pre-output rate rejection, shared pacing, persistent recovery history, and one total request deadline.
- Keeps distinct errors for queue limits, runtime expiration, access denial, unreadable mode, and actual notebook code mode.
- Public copy adds a loopback port selector, offline configuration checking, a non-overwriting template command, pinned dependencies, offline CSS acceptance, and publication documentation. The working source installation is not modified.
- Optional Windows `start.bat` creates the local environment and installs pinned runtime dependencies when needed, then forwards arguments and the Python CLI's exit code.
- Current verification results are in `docs/VALIDATION.md`; previous private-workspace results are not used as acceptance for this copy.

## 12.12.2 and 12.12.1

The existing reports describe pacing and cooldown state, ZCode-compatible rate error metadata, independent memory execution scopes, and serial delivery of native batches when parallel tools are disabled.

## 12.12 — Native frontend architecture

The adapter began supplying Molab frontend tool definitions, assembling native input events, and representing client tool results as native history. Manual/agent mode replaced notebook code mode for external client tools. Text command parsing remained a compatibility path.

## 12.11

The source changelog records receipt coordination, persistent operation states, idempotency protection, bounded terminal output, strict JSON/SSE boundaries, and isolated offline acceptance utilities.

## 12.10.3

The root-cause audit records a fix to command dispatch: command markers in ordinary prose or source text no longer trigger a text-frame parser. Incomplete anchored commands remain invalid.

## 12.7

The regression audit records stricter SSE EOF/UTF-8 boundaries, JSON and schema validation, late-error handling, and protection against incomplete tool delivery. These historical counts are not presented as current release results.

## Earlier prototypes and textual tool calls

The archived 12.6 README describes advisory small-action output guidance and the earlier `@@TOOL_CALL` text protocol. Existing early reports cover textual frames and JSON envelopes. More precise undocumented dates and changes are intentionally not reconstructed.
